class Pantallas extends Producto {
  constructor(referencia, marca, peso, precio,tamaño) {
  super(referencia, marca, peso, precio);
    this.tamaño = tamaño;
  }
}
