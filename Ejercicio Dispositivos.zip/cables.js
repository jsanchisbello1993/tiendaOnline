class Cables extends Producto {
  constructor(referencia, marca, peso, precio,tipo) {
  super(referencia, marca, peso, precio);
  this.tipo = tipo;
  }
}
