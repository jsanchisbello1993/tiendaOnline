class Teclados extends Producto {
  constructor(referencia, marca, peso, precio,numero_teclas) {
  super(referencia, marca, peso, precio);
    this.numero_teclas = numero_teclas;
  }
}
