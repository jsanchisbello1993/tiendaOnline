class Producto {
  constructor(referencia, marca, peso, precio) {
    this.referencia = referencia;
    this.marca = marca;
    this.peso = peso;
    this.precio = precio;
  }
}
