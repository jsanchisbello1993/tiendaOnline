class Ratones extends Producto {
  constructor(referencia, marca, peso, precio, inalámbrico_cable) {
  super(referencia, marca, peso, precio);
    this.inalámbrico_cable = inalámbrico_cable;
  }
}
